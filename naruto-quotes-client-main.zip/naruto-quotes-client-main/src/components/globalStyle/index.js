export * from './GlobalStyle';
